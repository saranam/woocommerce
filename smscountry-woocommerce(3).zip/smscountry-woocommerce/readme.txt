==== SMSCounrty ====

Developed By : Mapweb Technologies

==== Description ====

There will be automatically SMS alerts sent to customers on specific triggers like place new order,signup verification,changed the status of the Order,New Contact Inquiry etc.

smscountry plugin is works great having control using admin panel for sending sms.user can have facility to control if want to send sms or not.if any user placing order he/she will get sms for placing order as notification and also admin will get notification of placing new order on our site.admin has facility to enable or disable sms send option.if it enable user and admin willget sms for when order status changed,any new user get register and verify registered or new user ,contact enquiry etc.it will works with any theme.

  Here Plugin having four tabs ie API Setting ,User Template,Admin Template & SMS History.in api setting we need to do some settings required for smscountry api.User Template option that means here having control of sending sms to user for sign up,signup verification for new user or for existing user,new placed order ,order status change.in admin template here admin will get all notification of placed new order,new contact enquiry,sign up,return order etc.here also get notification daily,weekly,monthly  for how many user get registered on site.in sms history maintain all sms history.


==== Installation ====

In your WordPress admin, go to Plugins > Add New to install SMSCountry Plugin ,or:


1. Upload the smscountry plugin to the /wp-content/plugins/ directory of your site.
2. Activate the plugin through the 'Plugins' menu in WordPress.





